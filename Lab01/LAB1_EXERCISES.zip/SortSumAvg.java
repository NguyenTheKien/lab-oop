import java.util.Arrays;
import java.util.Scanner;

public class SortSumAvg {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    
    int sum = 0;
    
    System.out.println("Enter array size: ");
    int count = Integer.parseInt(keyboard.nextLine());
    
    int[] array = new int[count];
    
    for (int i = 0; i < count; i++) {
      System.out.println("Enter array element (integer only): ");
      array[i] = Integer.parseInt(keyboard.nextLine());
      sum += array[i];
    }
    System.out.println("Original array: " + Arrays.toString(array));
    Arrays.sort(array);
    System.out.println("Sorted array: " + Arrays.toString(array));
    System.out.println("Sum: " + sum);
    System.out.println("Avarage: " + (double)sum/count);
    
    keyboard.close();
    System.exit(0);
  }
}
