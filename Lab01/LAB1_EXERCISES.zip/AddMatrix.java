import java.util.Scanner;

public class AddMatrix {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Enter number of rows: ");
    int rowNum = Integer.parseInt(keyboard.nextLine());
    System.out.println("Enter number of columns: ");
    int colNum = Integer.parseInt(keyboard.nextLine());
    
    int[][] array1 = new int[rowNum][colNum], array2 = new int[rowNum][colNum];
    
    System.out.println("Enter first matrix");
    for (int i = 0; i < colNum; i++) {
      for (int j = 0; j < rowNum; j++) {
        System.out.println("Enter element at column " + (i+1) + ", row " + (j+1) + ": ");
        array1[j][i] = Integer.parseInt(keyboard.nextLine()); //filling by column
      }
    }
    
    System.out.println("Enter second matrix");
    for (int i = 0; i < colNum; i++) {
      for (int j = 0; j < rowNum; j++) {
        System.out.println("Enter element at column " + (i+1) + ", row " + (j+1) + ": ");
        array2[j][i] = Integer.parseInt(keyboard.nextLine()); //filling by column
      }
    }
    System.out.println("First matrix");
    for (int i = 0; i < rowNum; i++) {
      for (int j = 0; j < colNum; j++)
          System.out.print(array1[i][j] + " ");

      System.out.println();
    }
    System.out.println("Second matrix");
    for (int i = 0; i < rowNum; i++) {
      for (int j = 0; j < colNum; j++)
          System.out.print(array2[i][j] + " ");

      System.out.println();
    }
    System.out.println("Sum matrix");
    for (int i = 0; i < rowNum; i++) {
      for (int j = 0; j < colNum; j++)
          System.out.print((array1[i][j]+array2[i][j]) + " ");

      System.out.println();
    }
    
    keyboard.close();
    System.exit(0);
  }

}
