import java.util.Scanner;

public class DayCountOfMonth {
  public static boolean isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
  }

  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    
    int year = 0, days = 0;
    String month = "";
    int validMonth = 1;
    while(true) {
      try {
        System.out.println("Enter year (numeric only, Ex: 1999): ");
        year = Integer.parseInt(keyboard.nextLine());
        break;
      }
      catch(NumberFormatException e) {
        System.out.println("Invalid input. Please enter numeric values only");
      }
    }
    
    do {
      System.out.println("Enter month (name, abbreviation, number): ");
      String strMonth = keyboard.nextLine();
      validMonth = 1;

      switch (strMonth) {
      case "january":
      case "jan":
      case "jan.":
      case "1":
        month = "January";
        days = 31;
        break;
      case "february":
      case "feb":
      case "feb.":
      case "2":
        month = "February";
        if (isLeapYear(year)) days = 29;
        else days = 28;
        break;
      case "march":
      case "mar":
      case "mar.":
      case "3":
        month = "March";
        days = 31;
        break;
      case "april":
      case "apr":
      case "apr.":
      case "4":
        month = "April";
        days = 30;
        break;
      case "may":
      case "5":
        month = "May";
        days = 31;
        break;
      case "june":
      case "jun":
      case "jun.":
      case "6":
        month = "June";
        days = 30;
        break;
      case "july":
      case "jul":
      case "jul.":
      case "7":
        month = "July";
        days = 31;
        break;
      case "august":
      case "aug":
      case "aug.":
      case "8":
        month = "August";
        days = 31;
        break;
      case "september":
      case "sep":
      case "sep.":
      case "9":
        month = "September";
        days = 30;
        break;
      case "october":
      case "oct":
      case "oct.":
      case "10":
        month = "October";
        days = 31;
        break;
      case "november":
      case "nov":
      case "nov.":
      case "11":
        month = "November";
        days = 30;
        break;
      case "december":
      case "dec":
      case "dec.":
      case "12":
        month = "December";
        days = 31;
        break;
      default:
        System.out.println("Invalid input. Please enter a valid month.");
        validMonth = 0;
        break;
      }
    } while(validMonth == 0);
    
    System.out.println("Month: " + month);
    System.out.println("Number of days: " + days);
    keyboard.close();
  }
}
