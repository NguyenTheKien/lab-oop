import java.util.Scanner;
public class DrawTriangle {

  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    
    System.out.println("Height of your triangle in stars (*): ");
    int height = keyboard.nextInt();
    
    for (int i = 0 ; i < height; i++) {
      for (int j = 0; j < height - i - 1; j++) {
        System.out.print(" ");
      }
      
      for (int j = 0; j < 2*i+1; j++) {
        System.out.print("*");
      }
      
      System.out.println();
    }
    
    keyboard.close();
  }

}
