  
public class Cart {
  
  public static final int MAX_NUMBER_ORDERED = 20;
  private DigitalVideoDisc[] itemsOrdered = new DigitalVideoDisc[MAX_NUMBER_ORDERED];
  private int qtyOrdered = 0;
  
  public void addDigitalVideoDisc(DigitalVideoDisc disc) {
    //TO DO
    if (qtyOrdered == MAX_NUMBER_ORDERED) {
      System.out.println("Add disc failed, the cart is full.");
      return;
    } else {
      itemsOrdered[qtyOrdered] = disc;
      qtyOrdered += 1;
      System.out.println("The disc \"" + disc.getTitle() + "\" has been added!");
    }
    if (qtyOrdered == MAX_NUMBER_ORDERED) {
      System.out.println("The cart is full!");
    }
  }
  
  public void removeDigitalVideoDisc(DigitalVideoDisc disc) {
    //TO DO
    for (int i = 0; i < qtyOrdered; i++) {
      if (itemsOrdered[i] == disc) {
        for (int j = i; j < qtyOrdered - 1; j++ ) {
          itemsOrdered[j] = itemsOrdered[j + 1];
        }
        itemsOrdered[qtyOrdered - 1] = null;
        qtyOrdered -= 1;
        System.out.println("The disc \"" + disc.getTitle() + "\" has been removed from the cart.");
        return;
      }
    }
    System.out.println("Disc \"" + disc.getTitle() + "\" not found in cart.");
  }
  
  public float totalCost() {
    float total = 0;
    for (int i = 0; i < qtyOrdered; i++) {
      total += itemsOrdered[i].getCost();      
    }
    return total;
  }
}

